<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>RecipeFinder</title>
    <!--  external css link -->
 
    <link rel="stylesheet" href="{{asset('assets/recipe.css')}}">
    <!-- bootstrap css link -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <!-- bootstrap javascript link -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script>
     <!-- font link -->
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css">
     <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</head>

<body>
     
     <nav class="navbar navbar-expand-sm bg-warning sticky-top">
            <div class="container">
                 <a href="" class="navbar-brand"><img class="img-brand" src="assets/brands.png" alt=""></a>

                 <button class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#NavbarId" >
                 <span class="navbar-toggler-icon"></span>
                 </button>
                 <div class="collapse navbar-collapse" id="NavbarId">
                    <ul class="navbar-nav ms-auto">
                        <li class="nav-item"><a class="nav-link" href="#hero">Home</a></li>
                        <li class="nav-item"><a class="nav-link" href="#categories">categories</a></li>
                        <li class="nav-item"><a class="nav-link" href="{{ route('details') }}">Detail Page</a></li>
                        <li class="nav-item"><a class="nav-link" href="{{route('Abouts') }}">About Us</a></li>
                         <li class="nav-item"><a class="nav-link" href="#contactus">Contact Us</a></li>
                        <li class="nav-item dropdown">
   
                   </ul>
                     <div class="d-flex align-items-center">
                     <form class="d-flex">
                     <input class="form-control me-2" type="search" placeholder="Search recipes..." aria-label="Search">
                     <button class="btn btn-dark" type="submit">Search</button>
                    </form>
                    <a href="/login" class="btn btn-outline-danger ms-3" id="login-btn">LOG IN</a>
                     </div>

                    

                 </div>

            </div>

        </nav>
        <section id="home"> 
 
            <div class="carousel slide" id="someID" data-bs-ride="carousel">
            <div class="carousel-indicators">
                <button data-bs-target="#someID" data-bs-slide-to="0" class="active"></button>
                <button data-bs-target="#someID" data-bs-slide-to="1" ></button>
                <button data-bs-target="#someID" data-bs-slide-to="2" ></button>
              </div>
            <div class="carousel-inner ">
             
                <div class="carousel-item active">
                    <img src="assets/images/background.jpg" class="d-block w-100" alt="">

                </div>
                <div class="carousel-item ">
                    <img src="assets/images/slider.jpg" class="d-block w-100" alt="">

                </div>
                <div class="carousel-item">
                    <img src="assets/images/slid.jpg" class="d-block w-100" alt="">

                </div>
                <button class="carousel-control-prev" data-bs-target="#someID" data-bs-slide="prev">
                    <span class="carousel-control-prev-icon"></span>
                </button>
                <button class="carousel-control-next" data-bs-target="#someID" data-bs-slide="next">
                    <span class="carousel-control-next-icon"></span>
                </button>


            </div>

        </div> 

    </section>
    
   
 <!-- <div class="hero-section" style="background-image: url('assets/images/background.jpg');">
    <div class="overlay">
        <h1>Find Your Favorite Recipe</h1>
        <form class="search-bar">
            <input type="text" placeholder="Search for recipes..." />
            <button type="submit">Search</button>
        </form>
    </div>
</div>  -->
  

          Recipes Categories 

<section id="categories" class="container mt-5">
    <h2 class="text-center mb-4">Recipe Categories</h2>
    <div class="row">
        <div class="col-md-3">
            <div class="card">
                <img src="assets/images/biryaniimg.jpeg" class="card-img-top" alt="Biryani">
                <div class="card-body text-center">
                    <h5 class="card-title">Biryani</h5>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card">
                <img src="assets/images/sandwich.jpg" class="card-img-top" alt="Sandwich">
                <div class="card-body text-center">
                    <h5 class="card-title">Sandwich</h5>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card">
                <img src="assets/images/chickenpizz.jpeg" class="card-img-top" alt="pizza">
                <div class="card-body text-center">
                    <h5 class="card-title">pizza</h5>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card">
                <img src="assets/images/pasta.jpeg" class="card-img-top" alt="Sandwich">
                <div class="card-body text-center">
                    <h5 class="card-title">pasta</h5>
                </div>
            </div>
        </div>
    </div>
    
</section>  
 <!-- Recipe features  -->
 <section id="featured-recipes" class="py-5">
    <div class="container">
        <h2 class="text-center mb-4">Featured Recipes</h2>
        <div class="row ">
            <div class="col-md-3 d-flex">
                <div class="card shadow">
                    <img src="assets/images/chickenb.jpeg" class="card-img-top" alt="Biryani">
                    <div class="card-body">
                        <h5 class="card-title">Chicken Biryani</h5>
                        <p class="card-text">Delicious and spicy biryani..</p>
                        <a href=" {{ route('details', ['id' => 1]) }}" class="btn btn-warning">View Recipe</a>{{ route('details') }}
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card shadow">
                    <img src="assets/images/custered.jpeg" class="card-img-top" alt="choclate">
                    <div class="card-body">
                        <h5 class="card-title">Custured Recipe</h5>
                        <p class="card-text">Rich and creamy custered.</p>
                        <a href="{{ route('details', ['id' => 2]) }}" class="btn btn-warning">View Recipe</a>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card shadow">
                    <img src="assets/images/sandwitch.jpeg" class="card-img-top" alt="Sandwich">
                    <div class="card-body">
                        <h5 class="card-title">Cheesy Sandwich</h5>
                        <p class="card-text">A quick and delicious sandwich for a perfect snack.</p>
                        <a href="#" class="btn btn-warning">View Recipe</a>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card shadow">
                    <img src="assets/images/kheer.jpeg" class="card-img-top" alt="">
                    <div class="card-body">
                        <h5 class="card-title">kheer recipe</h5>
                        <p class="card-text">Crispy and delicious</p>
                        <a href="#" class="btn btn-warning">View Recipe</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
 


<section id="contactus" class="py-5">
    <div class="container">
        <div class="row">
            <div class="col-md-5">
                <div class="card shadow">
                <img src="assets/images/college.jpeg" class="card-img-top w-100 h-100" alt="">


                </div>

            </div>
            <div class="col-md-7">
            <h2 class="mb-4">Contact Us</h2>
            <p>Feel free to contact us for different recipes. You can explore various recipes in categories or search your favorite ones. We also provide video tutorials for better guidance.</p>
            <div class="mt-3">
                 <h1> <i class="fa-solid fa-location-dot"></i> Address</h1>
                 <p>Government Post Graduate college Satellite Town Gujranwala.</p>
                 </div>

                 <div class="mt-4">
                 <h1> <i class="fa-solid fa-phone-volume"></i> Phone</h1>
                 <p>(505) 792-2430</p>
                 </div>

                 <div class="mt-3">
                 <h1> <i class="fa-solid fa-envelope"></i> E-Mail</h1>
                 <p>demo@yourdomain.com</p>

                 </div>


            </div>

               
 

        </div>

    </div>

<footer class="bg-secondary text-white py-5"> 
      <div class="container"> 
        <div class="row text-center text-md-start ">
          <div class=" col-12 col-md-4">
            <p>&copy; 2025 Recipe Finder. all rights reserved</p>
           

          </div>
          <div class=" col-12 col-md-6">

          </div>
          <div class=" col-12 col-md-2 justify-content-center">
          <i class="fa-brands fa-square-facebook me-3 fs-3"></i>
            <i class="fa-brands fa-square-youtube me-3 fs-3"></i>
            <i class="fa-brands fa-square-twitter me-3 fs-3"></i>
            <i class="fa-brands fa-square-instagram  fs-3"></i>


          </div>

        </div>

      </div>
</footer>
 
    
    

</body>
</html>