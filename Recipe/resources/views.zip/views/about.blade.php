<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us Page </title>
    <!-- font link -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css">

</head>
<body>
    <section>
        <div class="container1">
            <div class="content section">
                <div class="title">
                    <h1>About Us</h1>

                </div>
                <div class="content">
                    <p>  Welcome to <strong>Recipe Finder</strong>, your ultimate destination for discovering delicious and easy-to-make recipes. Our goal is to make cooking an enjoyable experience for everyone, whether you're a beginner or an expert in the kitchen. We provide a variety of recipes with step-by-step instructions, helping you create amazing dishes effortlessly. At Recipe Finder, we believe that good food brings people together, and that’s why we are committed to offering a diverse collection of recipes that cater to all tastes and preferences. Explore new flavors, experiment with ingredients, and make every meal special with Recipe Finder!
                    </p>
                    <div class="button">
                        <a href="">Read More</a>

                    </div>

                </div>
                <div class="social">
                    <a href=""><i class="fa-brands fa-square-facebook me-3 fs-3"></i></a>
                    <a href=""><i class="fa-brands fa-square-youtube me-3 fs-3"></i></a>
                    <a href=""><i class="fa-brands fa-square-twitter me-3 fs-3"></i></a>
                    <a href=""><i class="fa-brands fa-square-instagram me-3 fs-3"></i></a>



                </div>

            </div>
            <div class="image-section">
                <img src="assets/images/ab.webp" alt="">

            </div>

        </div>
    </section>
    
</body>
</html>