@extends('layouts.master')

@section('main')
<div>
    <form action="/Recipe">
        <label for="recipe-name">Recipe Name:</label>
        <input type="text" required id="recipe-name" >
        <label for="recipe-name">Category:</label>
        <input type="text"  id="recipe-name" >
        <label for="recipe-name">Recipe Name:</label>
        <input type="text" id="recipe-name">
        <button type="submit">Save Recipe</button>
    </form>
</div>
@endextends