<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>table</title>
</head>
<body>
    <table class="table bg-primary">
        <thead>
            <tr bg->
                <th>Id</th>
                <th>Name</th>
                <th>Class</th> 
                 
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>100</td>
                <td>fatima</td>
                <td>10</td>
            </tr>
            <tr>
                <td>101</td>
                <td>ayesha</td>
                <td>10</td>
            </tr>
            <tr>
                <td>102</td>
                <td>maryam</td>
                <td>10</td>
            </tr>
            <tr>
                <td>103</td>
                <td>fatima</td>
                <td>10</td>
            </tr>
        </tbody>

    </table>
    
</body>
</html>