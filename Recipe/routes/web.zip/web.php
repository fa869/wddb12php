<?php

use Illuminate\Support\Facades\Route;
Auth::routes();
Route::get('/', function () {
    return view('welcome');
});
Route::get('/', function () {
    return view('Recipe');
})->name('Recipe');

Route::get('/Finder', function () {
    return view('Recipe');
});



// Route::get('/Abouts',function(){
//     return view('About');
// })->name('Abouts');


Route::get('/admin', function () {
    return view('layouts.master');
});
Route::get('/Recipe', function () {
    return view('Recipe.index');
});

Route::get('/Recipe/create', function () {
    return view('Recipe.index');
});



 Route::get('/details',function(){
    return view('details');

 })->name('details');

  
 
 

// Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
